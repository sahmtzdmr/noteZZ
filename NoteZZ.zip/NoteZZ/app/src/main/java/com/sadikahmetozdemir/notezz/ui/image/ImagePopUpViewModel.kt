package com.sadikahmetozdemir.notezz.ui.image

import com.sadikahmetozdemir.notezz.base.BaseViewModel

class ImagePopUpViewModel : BaseViewModel()
